package org.efrei.start.create;

public class CreateSalle {

    private String numerodesalle;
    private String movieId;

    public String getNumerodesalle() {
        return numerodesalle;
    }

    public void setNumerodesalle(String numerodesalle) {
        this.numerodesalle = numerodesalle;
    }

    public String getMovieId() {
        return movieId;
    }

    public void setMovieId(String movieId) {
        this.movieId = movieId;
    }
}
