package org.efrei.start.models;
import jakarta.persistence.*;

@Entity
public class Ad {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Column(name = "brand", nullable = false)
    private String brand;

    @Column(name = "timer", nullable = false)
    private int timer;

    @ManyToOne
    @JoinColumn(name = "movie_id")
    private Movie movie;

    public Ad(String Brand, String Timer) {
        this.brand = brand;
        this.timer = timer;
    }


    public org.efrei.start.models.Movie getMovie() {
        return movie;
    }

    public void setMovie(org.efrei.start.models.Movie movie) {
        this.movie = movie;
    }


    public Ad() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {this.brand = brand;}

    public int getTimer() {
        return timer;
    }

    public void setTimer(int timer) {this.timer = timer;}
}
