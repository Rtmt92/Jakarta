package org.efrei.start.models;
import jakarta.persistence.*;

@Entity
public class Salle {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Column(name = "numerodesalle", nullable = false)
    private String numerodesalle;

    @ManyToOne
    @JoinColumn(name = "movie_id")
    private Movie movie;

    public Salle(String numerodesalle) {
        this.numerodesalle = numerodesalle;
    }


    public org.efrei.start.models.Movie getMovie() {
        return movie;
    }

    public void setMovie(org.efrei.start.models.Movie movie) {
        this.movie = movie;
    }


    public Salle() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNumerodesalle() {
        return numerodesalle;
    }

    public void setNumerodesalle(String numerodesalle) {
        this.numerodesalle = numerodesalle;
    }

}
