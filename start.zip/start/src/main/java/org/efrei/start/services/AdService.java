package org.efrei.start.services;

import org.efrei.start.create.CreateAd;
import org.efrei.start.models.Ad;
import org.efrei.start.models.Movie;
import org.efrei.start.repositories.ActorRepository;
import org.efrei.start.repositories.AdRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdService {

    private final AdRepository repository;
    private final MovieService movieService;

    @Autowired
    public AdService(AdRepository repository, MovieService movieService) {
        this.repository = repository;
        this.movieService = movieService;
    }

    public List<Ad> findAll(){
        // SELECT * from actor
        System.out.println(repository.findAll());
        return repository.findAll();
    }

    public void create(CreateAd createAd) {
        Ad ad = new Ad();
        Movie movie = movieService.findById(createAd.getMovieId());
        ad.setTimer(createAd.getTimer());
        ad.setBrand(createAd.getBrand());
        ad.setMovie(movie);
        repository.save(ad);
    }

    public Ad findById(String id) {
        // SELECT * FROM actor WERE id = :id
        return repository.findById(id).orElse(null);
    }

    public void deleteById(String id) {
        repository.deleteById(id);
    }

    public void update(String id, Ad ad) {

        //UPDATE actor SET (firstname, name) VALUES (:firstname, :name) where id = :id;
        Ad updatedAd = findById(id);
        updatedAd.setBrand(ad.getBrand());
        updatedAd.setTimer(ad.getTimer());
        repository.save(updatedAd);
    }



}
