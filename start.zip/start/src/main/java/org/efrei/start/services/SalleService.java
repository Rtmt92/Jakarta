package org.efrei.start.services;

import org.efrei.start.create.CreateSalle;
import org.efrei.start.models.Movie;
import org.efrei.start.models.Salle;
import org.efrei.start.repositories.SalleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SalleService {

    private final SalleRepository repository;
    private final MovieService movieService;

    @Autowired
    public SalleService(SalleRepository repository, MovieService movieService) {
        this.repository = repository;
        this.movieService = movieService;
    }

    public List<Salle> findAll(){
        // SELECT * from actor
        System.out.println(repository.findAll());
        return repository.findAll();
    }

    public void create(CreateSalle createSalle) {
        Salle salle = new Salle();
        Movie movie = movieService.findById(createSalle.getMovieId());
        salle.setNumerodesalle(createSalle.getNumerodesalle());
        salle.setMovie(movie);
        repository.save(salle);
    }

    public Salle findById(String id) {
        // SELECT * FROM actor WERE id = :id
        return repository.findById(id).orElse(null);
    }

    public void deleteById(String id) {
        repository.deleteById(id);
    }

    public void update(String id, Salle salle) {

        //UPDATE actor SET (firstname, name) VALUES (:firstname, :name) where id = :id;
        Salle updatedSalle = findById(id);
        updatedSalle.setNumerodesalle(salle.getNumerodesalle());
        repository.save(updatedSalle);
    }



}
